#include <hellomake.h>

int main() {
  // chamda da funcao
  myPrintHelloMake();

  return(0);
}
