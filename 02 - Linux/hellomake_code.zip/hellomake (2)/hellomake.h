/*
exemplo do arquivo include
*/

void myPrintHelloMake(void);
