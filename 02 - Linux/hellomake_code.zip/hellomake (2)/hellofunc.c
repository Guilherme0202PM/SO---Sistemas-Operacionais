#include <stdio.h>
#include <hellomake.h>

void myPrintHelloMake(void) {

  printf("Olá arquivo makefile!\n");

  return;
}
